function Home(props:any)
{
    return(
        <>
            <h1>Home</h1>
        </>
    )
}
export {
    Home
}