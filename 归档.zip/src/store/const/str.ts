export const STRAWBERRY = 'strawberry'
export const PINEAPPLE = 'pineapple'

